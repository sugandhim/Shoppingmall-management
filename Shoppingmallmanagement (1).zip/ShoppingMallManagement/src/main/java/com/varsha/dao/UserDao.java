package com.varsha.dao;

import org.springframework.jdbc.core.JdbcTemplate;

import com.varsha.beans.OrderDetails;
import com.varsha.beans.User;


public class UserDao {

	JdbcTemplate template;

	public void setTemplate(JdbcTemplate template) {    
	    this.template = template;    
	}

		public int save(User p) {    
		    String sql="insert into users(name,password) values('"+p.getName()+"','"+p.getPassword() +"')";    
		    return template.update(sql);

	}
		
		
		public int save(OrderDetails o) {    
		    String sql="insert into orderdetails(name,mobilenum,address,state,city,pincode) values('"+o.getName()+"','"+o.getMobilenum()+"', '"+o.getAddress()+"', '"+o.getState() +"', '"+o.getCity() +"', '"+o.getPincode() +"',  )";    
		    return template.update(sql);

	}
		
}
